// JavaScript for VisionVentures Landing Page

document.getElementById("joinBtn").addEventListener("click", function () {
  alert("Thank you for your interest! We'll reach out soon with exciting opportunities.");
});